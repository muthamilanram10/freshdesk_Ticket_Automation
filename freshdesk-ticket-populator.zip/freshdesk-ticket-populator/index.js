require('dotenv').config();
const cron = require('node-cron');
const logger = require('./config/logger');
const {
    getContacts,
    getAgents,
    createTicket,
    assignToAgent,
    addReply,
    closeTicket,
} = require('./services/freshdesk');

function handleTicketWorkflow(ticketDetails) {
    const { ticketId, customerEmail, agentName, agentId, messageHistory, customerId } = ticketDetails;

    const agentFirstReplyCron = `*/5 * * * *`;
    const agentFirstReplyTask = cron.schedule(agentFirstReplyCron, async () => {
        try {
            const message = `Hello, this is ${agentName}. I’m here to assist you with your issue. Could you provide more details about the problem with your order?`;
            await addReply(ticketId, 'agent', agentId, message);
            messageHistory.push(`Agent: ${message}`);
            logger.info(`Agent reply added for ticket ${ticketId}: ${message}`);
        } catch (error) {
            logger.error(`Error adding agent reply for ticket ${ticketId}:`, error.response?.data || error.message);
        } finally {
            agentFirstReplyTask.stop();
        }
    });

    const customerReplyCron = `*/10 * * * *`;
    const customerReplyTask = cron.schedule(customerReplyCron, async () => {
        try {
            const message = `Hi, my order #98765 was supposed to arrive yesterday, but I haven’t received it yet. Can you check the status for me?`;
            await addReply(ticketId, 'customer', customerId, message);
            messageHistory.push(`Customer: ${message}`);
            logger.info(`Customer reply added for ticket ${ticketId}: ${message}`);
        } catch (error) {
            logger.error(`Error adding customer reply for ticket ${ticketId}:`, error.response?.data || error.message);
        } finally {
            customerReplyTask.stop();
        }
    });

    const agentResolutionCron = `*/15 * * * *`;
    const agentResolutionTask = cron.schedule(agentResolutionCron, async () => {
        try {
            const message = `Thank you for your patience. This is ${agentName} again. Your order is delayed due to a shipping issue but has been expedited and is on its way now. You should receive it within 2-3 business days.`;
            await addReply(ticketId, 'agent', agentId, message);
            messageHistory.push(`Agent: ${message}`);
            logger.info(`Final agent reply added for ticket ${ticketId}: ${message}`);
        } catch (error) {
            logger.error(`Error adding final agent reply for ticket ${ticketId}:`, error.response?.data || error.message);
        } finally {
            agentResolutionTask.stop();
        }
    });

    const closeTicketCron = `*/20 * * * *`;
    const closeTicketTask = cron.schedule(closeTicketCron, async () => {
        try {
            await closeTicket(ticketId);
            messageHistory.push(`Ticket ${ticketId} closed.`);
            logger.info(`Ticket ${ticketId} marked as closed.`);
        } catch (error) {
            logger.error(`Error closing ticket ${ticketId}:`, error.response?.data || error.message);
        } finally {
            closeTicketTask.stop();
        }
    });
}

async function createAndHandleTicket() {
    logger.info(`Ticket creation initiated at ${new Date().toISOString()}`);
    try {
        const contacts = await getContacts();
        if (!contacts.length) throw new Error('No active contacts found.');
        const randomContact = contacts[Math.floor(Math.random() * contacts.length)];

        const agents = await getAgents();
        if (!agents.length) throw new Error('No active agents found.');
        const randomAgent = agents[Math.floor(Math.random() * agents.length)];

        const ticket = await createTicket(
            `Order Delivery Issue for ${randomContact.name}`,
            `Hi, I have an issue with my order delivery. Please assist.`,
            randomContact.email
        );
        logger.info(`Ticket ${ticket.id} created for customer ${randomContact.name} (${randomContact.email})`);

        await assignToAgent(ticket.id, randomAgent.id);
        logger.info(`Ticket ${ticket.id} assigned to agent ${randomAgent.contact.name}`);

        const ticketDetails = {
            ticketId: ticket.id,
            customerName: randomContact.name,
            customerId: randomContact.id,
            customerEmail: randomContact.email,
            agentName: randomAgent.contact.name,
            agentId: randomAgent.id,
            messageHistory: [
                `Ticket created by customer ${randomContact.name}. Assigned to agent ${randomAgent.contact.name}.`,
            ],
        };

        handleTicketWorkflow(ticketDetails);
    } catch (error) {
        logger.error('Error during ticket creation:', error.response?.data || error.message);
    }
}

(async function startTicketProcess() {
    await createAndHandleTicket();

    const cronExpression = '0 * * * *';
    cron.schedule(cronExpression, async () => {
        await createAndHandleTicket();
    });

    logger.info('Ticket creation cron job scheduled.');
})();
