const cron = require('node-cron');
require('dotenv').config(); // Load environment variables

const { createTicket } = require('./services/freshdesk');
const logger = require('./config/logger');


async function scheduleTicketCreation(ticketsPerDay) {
    const interval = 2;

    cron.schedule(`*/${interval} * * * *`, async () => {
        try {
            const ticket = await createTicket(
                'Demo Ticket',
                'This is a demo ticket created for assignment purposes.'
            );
            logger.info(`Ticket Created: ${ticket.id}`);
        } catch (error) {
            logger.error('Error during scheduled ticket creation:', error);
        }
    });
}

const ticketsPerDay = 10; 
scheduleTicketCreation(ticketsPerDay);
