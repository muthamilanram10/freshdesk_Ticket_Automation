const axios = require('axios');
const cron = require('node-cron');
const logger = require('../config/logger');

if (!process.env.FRESHDESK_API_KEY || !process.env.FRESHDESK_URL) {
    throw new Error('Missing FRESHDESK_API_KEY or FRESHDESK_URL in .env file');
}

const freshdeskAPI = axios.create({
    baseURL: process.env.FRESHDESK_URL,
    headers: {
        Authorization: `Basic ${Buffer.from(process.env.FRESHDESK_API_KEY).toString('base64')}`,
        'Content-Type': 'application/json',
    },
});

async function createTicket(subject, description) {
    try {
        const response = await freshdeskAPI.post('/api/v2/tickets', {
            subject,
            description,
            email: 'muthamilanram10@gmail.com',
            priority: 1,
            status: 2,
        });
        return response.data;
    } catch (error) {
        console.error('Error creating ticket:', error.response?.data || error.message);
        throw error;
    }
}

async function addReply(ticketId, replyType, message) {
    try {
        const endpoint = replyType === 'agent' ? '/reply' : '/notes';
        await freshdeskAPI.post(`/api/v2/tickets/${ticketId}${endpoint}`, {
            body: message,
        });
    } catch (error) {
        console.error(`Error adding ${replyType} reply:`, error.response?.data || error.message);
        throw error;
    }
}

const interval = 2;
const cronExpression = `*/${interval} * * * *`;

logger.info(`Scheduling ticket creation every ${interval} minutes with cron: ${cronExpression}`);


cron.schedule(`*/${interval} * * * *`, async () => {
    try {
        const ticket = await createTicket('Demo Ticket', 'Demo ticket for testing.');
        logger.info(`Ticket Created: ${ticket.id}`);

        setTimeout(async () => {
            await addReply(ticket.id, 'customer', 'This is a customer reply.');
            logger.info(`Customer reply added for ticket ${ticket.id}`);
        }, 300000); // 5 minutes

        setTimeout(async () => {
            await addReply(ticket.id, 'agent', 'This is an agent reply.');
            logger.info(`Agent reply added for ticket ${ticket.id}`);
        }, 600000); // 10 minutes
    } catch (error) {
        logger.error('Error during scheduled ticket creation or replies:', error);
    }
});


module.exports = { createTicket };
