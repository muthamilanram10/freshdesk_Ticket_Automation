const axios = require('axios');
const logger = require('../config/logger');

const freshdeskAPI = axios.create({
    baseURL: process.env.FRESHDESK_URL,
    headers: {
        Authorization: `Basic ${Buffer.from(process.env.FRESHDESK_API_KEY).toString('base64')}`,
        'Content-Type': 'application/json',
    },
});

async function getContacts() {
    try {
        const response = await freshdeskAPI.get('/api/v2/contacts');
        return response.data;
    } catch (error) {
        logger.error('Error fetching contacts:', error.response?.data || error.message);
        throw error;
    }
}

async function getAgents() {
    try {
        const response = await freshdeskAPI.get('/api/v2/agents');
        return response.data;
    } catch (error) {
        logger.error('Error fetching agents:', error.response?.data || error.message);
        throw error;
    }
}

async function createTicket(subject, description, email) {
    try {
        const response = await freshdeskAPI.post('/api/v2/tickets', {
            subject,
            description,
            email,
            priority: 1,
            status: 2,
        });
        return response.data;
    } catch (error) {
        logger.error('Error creating ticket:', error.response?.data || error.message);
        throw error;
    }
}

async function assignToAgent(ticketId, agentId) {
    try {
        await freshdeskAPI.put(`/api/v2/tickets/${ticketId}`, {
            responder_id: agentId,
        });
        logger.info(`Ticket ${ticketId} assigned to agent ${agentId}`);
    } catch (error) {
        logger.error(`Error assigning ticket ${ticketId} to agent ${agentId}:`, error.response?.data || error.message);
        throw error;
    }
}

async function addReply(ticketId, replyType, id, message) {
    try {
        const payload = {
            body: message,
        };
        if (replyType === 'agent') {
            payload.user_id = id || undefined;
        } else if (replyType === 'customer') {
            payload.user_id = id || undefined;
        }

        const response = await freshdeskAPI.post(`/api/v2/tickets/${ticketId}/reply`, payload);
        logger.info(`${replyType} reply added to ticket ${ticketId}: ${message}`);
        return response.data;
    } catch (error) {
        logger.error(
            `Error adding ${replyType} reply to ticket ${ticketId}:`,
            error.response?.data || error.message
        );
        throw error;
    }
}

async function closeTicket(ticketId) {
    try {
        await freshdeskAPI.put(`/api/v2/tickets/${ticketId}`, {
            status: 5,
        });
        logger.info(`Ticket ${ticketId} marked as closed`);
    } catch (error) {
        logger.error(`Error closing ticket ${ticketId}:`, error.response?.data || error.message);
        throw error;
    }
}

module.exports = {
    getContacts,
    getAgents,
    createTicket,
    assignToAgent,
    addReply,
    closeTicket,
};
